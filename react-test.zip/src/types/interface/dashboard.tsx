export interface Todos {
  completed: boolean;
  id: number;
  title: string;
  userId: number;
}
